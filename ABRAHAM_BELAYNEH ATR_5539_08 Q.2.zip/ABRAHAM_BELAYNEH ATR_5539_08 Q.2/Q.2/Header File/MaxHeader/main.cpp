#include <iostream>
#include "Maximum.h"


using namespace std;

int main()
{
    Maximum m;
    m.set(100,95,200);
    cout << "Maximum Number = " << m.get() <<endl;
    return 0;
}
