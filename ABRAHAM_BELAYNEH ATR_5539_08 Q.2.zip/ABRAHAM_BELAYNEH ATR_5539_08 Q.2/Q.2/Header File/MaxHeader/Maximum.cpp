
//This is the implementation file
//It contains the method definitions

#include "Maximum.h"

void Maximum::set(int num1, int num2, int num3)
{
    if(num1 > num2 && num1 > num3)
    {
        result=num1;
    }
    else if(num2 >num1 && num2 > num3)
    {
        result=num2;
    }
    else if(num3 > num1 && num3 > num2)
    {
        result=num3;
    }
    else if(num1 == num2 && num2 == num3 && num1 == num3)
    {
        result=0;
    }
}
int Maximum::get() const
{
    return result;
}
